from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter


def process_documents(file_path):
    # 加载文本文件并按字符数切片，保证语义完整性
    loader = TextLoader(file_path, encoding="utf-8")
    docs = loader.load()

    # 设定切片大小和重叠量，用于优化检索效果
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    return splitter.split_documents(docs)