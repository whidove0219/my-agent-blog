import os
from rag_engine import get_agent_executor
from data_processor import process_documents

# 素材目录配置
DATA_DIR = "./data_source"

def run_automation():
    # 遍历处理目录下的所有txt源文件
    files = [f for f in os.listdir(DATA_DIR) if f.endswith(".txt")]

    for filename in files:
        print(f"\n>>> 处理研报素材: {filename} ...")
        file_path = os.path.join(DATA_DIR, filename)

        # 初始化检索与分析引擎
        splits = process_documents(file_path)
        executor = get_agent_executor(splits)

        # 触发分析流程
        topic = filename.replace(".txt", "")
        result = executor.invoke({
            "messages": [("user", f"分析报告主题: {topic}。请基于文档内容进行深度解读。")]
        })

        # 输出结果至本地文件
        content = result["messages"][-1].content
        output_file = f"研报_{filename}"
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(content)
        print(f" 任务完成: {output_file}")

if __name__ == "__main__":
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    else:
        run_automation()