from langchain_openai import ChatOpenAI
from langchain_community.vectorstores import Chroma
from langchain_core.tools import create_retriever_tool
from langchain_huggingface import HuggingFaceEmbeddings
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import SystemMessage

def get_agent_executor(splits):
    # API 配置
    api_key = "sk-4cb49ebe1f1d4c7baf92260c2ea01af4"
    base_url = "https://api.deepseek.com"

    # Embedding 模型初始化与向量入库
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    vectorstore = Chroma.from_documents(splits, embeddings, persist_directory="./db")

    # 配置检索工具
    retriever_tool = create_retriever_tool(
        vectorstore.as_retriever(search_kwargs={"k": 3}),
        "policy_search",
        "查询研报素材中的政策与市场信息"
    )
    tools = [retriever_tool]

    # 初始化大模型推理引擎
    llm = ChatOpenAI(
        model="deepseek-chat",
        temperature=0,
        openai_api_key=api_key,
        openai_api_base=base_url
    )

    # 实例化 Agent 执行器
    return create_react_agent(llm, tools)